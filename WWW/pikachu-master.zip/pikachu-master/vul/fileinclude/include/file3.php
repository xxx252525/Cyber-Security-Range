<?php
$html.=<<<A
<img class=player src="include/kd.png" />
<p class=nabname>
Durant in 2007 first round draft sequence of the second was drafted by the Seattle supersonics, 2008 with the team moved to Oklahoma.In 2010, durant, 21, became the youngest NBA scoring champion, after two seasons in the NBA regular season scoring in a row.In 2014, durant and scoring with the NBA regular season MVP award (MVP). 
</p>
A;
?>