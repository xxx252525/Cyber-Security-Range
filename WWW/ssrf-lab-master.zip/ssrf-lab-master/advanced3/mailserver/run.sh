#!/bin/bash
service postfix start
while true; do
  sleep 10
done
