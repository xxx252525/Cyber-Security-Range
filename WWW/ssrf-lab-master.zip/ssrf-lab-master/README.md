# Please note that this repository has been archived and moved to the newer and more complete DVCA project:
https://github.com/m6a-UdS/dvca

# ssrf-lab
Lab for exploring SSRF vulnerabilities

The lab for October 4th is in the /ctf directory :-)
